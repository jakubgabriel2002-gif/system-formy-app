export interface Env {
  DB: D1Database;
  APP_ORIGIN?: string;
  API_ENV?: string;
}

type ChallengeRow = {
  id: string;
  slug: string;
  title: string;
  summary: string;
  duration_days: number;
  difficulty: string | null;
  access_level: string;
  price_amount_cents: number | null;
  currency: string;
};

const securityHeaders = {
  'content-type': 'application/json; charset=utf-8',
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'strict-origin-when-cross-origin',
  'cache-control': 'no-store',
};

function json(data: unknown, status = 200, extraHeaders: HeadersInit = {}): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...securityHeaders, ...extraHeaders },
  });
}

function corsHeaders(request: Request, env: Env): HeadersInit {
  const origin = request.headers.get('Origin');
  if (!origin || !env.APP_ORIGIN) return {};
  const allowed = env.APP_ORIGIN.split(',').map((value) => value.trim()).filter(Boolean);
  if (!allowed.includes(origin)) return {};
  return {
    'access-control-allow-origin': origin,
    'access-control-allow-methods': 'GET, OPTIONS',
    'access-control-allow-headers': 'content-type',
    'vary': 'Origin',
  };
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const headers = corsHeaders(request, env);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: { ...headers, 'access-control-max-age': '86400' } });
    }

    if (request.method !== 'GET') {
      return json({ error: 'method_not_allowed' }, 405, { allow: 'GET, OPTIONS', ...headers });
    }

    if (url.pathname === '/api/health') {
      return json({ status: 'ok', service: 'system-formy-api', environment: env.API_ENV ?? 'unset' }, 200, headers);
    }

    if (url.pathname === '/api/challenges') {
      try {
        const { results } = await env.DB.prepare(
          `SELECT c.id, c.slug, c.title, c.summary, c.duration_days,
                  c.difficulty, p.access_level, p.price_amount_cents, p.currency
           FROM challenges c
           INNER JOIN products p ON p.id = c.product_id
           WHERE c.status = 'published' AND p.status = 'published'
           ORDER BY c.sort_order ASC, c.created_at DESC
           LIMIT 100`,
        ).all<ChallengeRow>();

        return json({
          data: results.map((row) => ({
            id: row.id,
            slug: row.slug,
            title: row.title,
            summary: row.summary,
            durationDays: row.duration_days,
            difficulty: row.difficulty,
            access: row.access_level,
            // null means no confirmed price is configured. Never invent a price.
            priceAmountCents: row.price_amount_cents,
            currency: row.currency,
          })),
        }, 200, headers);
      } catch {
        return json({ error: 'service_unavailable', message: 'Katalog nie jest jeszcze skonfigurowany.' }, 503, headers);
      }
    }

    return json({ error: 'not_found' }, 404, headers);
  },
};
