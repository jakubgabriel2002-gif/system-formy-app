# SYSTEM FORMY — starter aplikacji

Pierwsza, uporządkowana baza techniczna aplikacji System Formy. Projekt jest przygotowany do dalszej rozbudowy, ale **nie jest jeszcze gotową platformą produkcyjną**. Interfejs ma działający tryb demonstracyjny; konta, zakup, subskrypcja oraz udostępnianie płatnych plików wymagają kolejnych etapów.

## Kierunek produktu

Interfejs i model danych przygotowano pod aktualny kierunek: **wyzwania, e-booki, subskrypcję Premium oraz indywidualne plany tworzone dla konkretnego klienta**. Nie zakładamy gotowych, uniwersalnych planów treningowych jako głównej oferty aplikacji. Starsze pliki ofertowe mogą opisywać wcześniejszy model i nie powinny po cichu nadpisywać nowych decyzji.

W projekcie nie ma wpisanych niepotwierdzonych cen. Przykładowe karty w katalogu mają wyraźne etykiety demonstracyjne; należy je zatwierdzić lub zastąpić prawdziwą ofertą przed publikacją.

## Co znajduje się w paczce

- React + TypeScript + Vite — mobilny, responsywny interfejs po polsku.
- Nawigacja: Start, Wyzwania, Biblioteka, Premium i Profil.
- Tryb demo: rozpoczęcie bezpłatnego wyzwania, zapisywanie zadań, oznaczanie ukończenia oraz filtrowanie katalogu.
- Manifest PWA i konfiguracja service workera dla publicznego szkieletu aplikacji.
- Cloudflare Worker API ze startowymi endpointami `GET /api/health` oraz `GET /api/challenges`.
- Schemat D1 dla użytkowników, produktów, wyzwań, zamówień, subskrypcji, uprawnień i indywidualnych planów.
- Początkowe workflow GitHub Actions do budowania frontend’u oraz późniejszego wdrożenia Pages / Worker.
- Instrukcja jednorazowego importu kodu do repozytorium z iPhone’a.

## Co działa, a co jeszcze nie

| Element | Status w tej paczce |
|---|---|
| Responsywny interfejs i nawigacja | Działa w trybie demo |
| Wyzwanie demo i zadania | Działają; zapis tylko w lokalnej przeglądarce |
| Wyszukiwanie i filtry katalogu | Działają na przykładowych danych |
| PWA / dodanie do ekranu początkowego | Konfiguracja przygotowana; wymaga hostingu HTTPS |
| Worker API | Kod startowy; wymaga skonfigurowania i wdrożenia |
| Cloudflare D1 | Schemat przygotowany; trzeba utworzyć bazę i zastosować schemat |
| Rejestracja / logowanie / reset hasła | Jeszcze niezaimplementowane |
| Prawdziwy katalog zarządzany przez administratora | Jeszcze niezaimplementowany |
| Stripe / checkout / webhooki | Jeszcze niezaimplementowane |
| Prywatne pliki R2 i weryfikacja zakupu | Schemat zaplanowany; endpointów dostępu jeszcze nie ma |
| Premium i odwołanie subskrypcji | Interfejs koncepcyjny; nieaktywne |
| Panel administratora | Jeszcze niezaimplementowany |
| Plan indywidualny i dostarczenie klientowi | Schemat startowy; proces niezaimplementowany |
| Testy end-to-end i audyt bezpieczeństwa | Do wykonania przed uruchomieniem dla klientów |

## Uruchomienie w środowisku developerskim

Wymagania: Node.js 22 lub zgodna wersja oraz npm.

```bash
npm install
npm run dev
```

Aby sprawdzić typy i przygotować build:

```bash
npm run typecheck
npm run build
```

Tryb demonstracyjny nie wymaga kluczy API. Plik `.env.example` zawiera jedynie opcjonalne miejsce na URL backendu.

## Układ katalogów

```text
src/                     interfejs React i dane demonstracyjne
src/data/catalog.ts      przykładowy katalog — nie jest cennikiem
src/lib/storage.ts       zapis stanu demo tylko w localStorage
src/lib/api.ts           pomocnik do komunikacji z API (jeszcze niewpięty w UI)
public/                  ikona oraz manifest PWA
worker/index.ts          początkowe endpointy Cloudflare Worker
worker/schema.sql        schemat Cloudflare D1
wrangler.toml            konfiguracja Cloudflare — wymaga prawdziwego D1 ID
.github/workflows/       automatyzacja GitHub Actions
scripts/                 instrukcja jednorazowego importu z iPhone’a
```

## Plan kolejnych etapów

1. Potwierdzić katalog produktów, nazwy, zakres, ceny, regulamin i zasady Premium.
2. Uruchomić D1 i Worker; dodać prawdziwe logowanie i autoryzację.
3. Zbudować panel administracyjny do zarządzania wyzwaniami, e-bookami i plikami.
4. Dodać checkout i webhooki z weryfikacją podpisu oraz idempotencją.
5. Przechowywać płatne pliki w prywatnym R2 i wydawać dostęp przez API po sprawdzeniu uprawnień.
6. Wdrożyć Premium z obsługą odnowień, anulowania i niezależnego dostępu do produktów kupionych jednorazowo.
7. Dodać zgłoszenia planów indywidualnych, ekran administracyjny i bezpieczne dostarczenie gotowego planu.
8. Przeprowadzić testy, przegląd prywatności, warunki sprzedaży i kontrolę bezpieczeństwa przed startem.

## Zasady bezpieczeństwa

- Nie dodawaj kluczy API, haseł ani plików `.env` do repozytorium.
- Nie wrzucaj płatnych PDF-ów do katalogu `public/` ani do publicznego repozytorium. Trzymaj je w prywatnym R2.
- Nie traktuj ukrycia przycisku w interfejsie jako zabezpieczenia. Dostęp do każdej płatnej treści musi być sprawdzany po stronie serwera.
- Po zakupie jednorazowym nadaj oddzielne uprawnienie do produktu. Nie kasuj go tylko dlatego, że skończy się subskrypcja Premium.
- Webhooki operatora płatności muszą weryfikować podpis i zabezpieczać przed wielokrotnym przetworzeniem tego samego zdarzenia.
- Schemat i endpointy są punktem startowym, nie zastępują implementacji logowania, kontroli dostępu, polityki prywatności ani audytu.

## Wdrożenie

Workflowy GitHub Actions są przygotowane jako szablon. Do publikacji frontendu na Cloudflare Pages potrzebujesz projektu Pages oraz sekretów repozytorium `CLOUDFLARE_API_TOKEN` i `CLOUDFLARE_ACCOUNT_ID`. Wdrożenie API wymaga dodatkowo utworzenia D1 w Cloudflare i wpisania prawdziwego `database_id` do `wrangler.toml`. Nie uruchamiaj publicznej sprzedaży na tym etapie.
