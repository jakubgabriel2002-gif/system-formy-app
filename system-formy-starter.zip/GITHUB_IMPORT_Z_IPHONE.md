# Jak wgrać projekt do GitHuba wyłącznie z iPhone’a

Ta instrukcja używa jednorazowego GitHub Actions do rozpakowania źródeł i zapisania ich jako normalne pliki w repozytorium. **Samo wysłanie ZIP-a do GitHuba nie rozpakowuje projektu** — dlatego wykonujemy jeszcze jeden krótki krok konfiguracyjny.

Repozytorium docelowe: `jakubgabriel2002-gif/system-formy-app`.

## 1. Wyślij ZIP do repozytorium

1. Pobierz `system-formy-starter.zip` i zapisz go w aplikacji **Pliki**.
2. Otwórz w Safari: <https://github.com/jakubgabriel2002-gif/system-formy-app> i zaloguj się.
3. W repozytorium wybierz **Add file → Upload files**.
4. Wybierz `system-formy-starter.zip` z aplikacji Pliki i zatwierdź zmianę na gałęzi `main`. Nazwa pliku w repozytorium musi być dokładnie `system-formy-starter.zip`.

## 2. Dodaj jednorazowy workflow importujący

1. Wróć do strony repozytorium, wybierz **Add file → Create new file**.
2. Jako nazwę pliku wpisz dokładnie `.github/workflows/import-starter-zip.yml`.
3. W aplikacji Pliki rozpakuj pobrany ZIP (stuknij ZIP). Otwórz plik `scripts/import-starter-zip.yml` i skopiuj całą jego zawartość do nowego pliku na GitHubie.
4. Zapisz plik przyciskiem **Commit changes** na gałęzi `main`.

## 3. Uruchom import

1. Otwórz zakładkę **Actions** w repozytorium.
2. Wybierz workflow **Import System Formy starter ZIP**.
3. Wybierz **Run workflow**, gałąź `main` i ponownie **Run workflow**.
4. Otwórz uruchomione zadanie i poczekaj, aż status będzie zielony. Workflow rozpakowuje źródła, usuwa z repozytorium plik ZIP i tworzy commit z normalnymi plikami projektu.

Jeżeli GitHub zablokuje zapis z komunikatem o uprawnieniach, otwórz **Settings → Actions → General → Workflow permissions** i wybierz **Read and write permissions**, o ile ustawienie jest dostępne dla Twojego konta. Następnie ponownie uruchom import. Nie dodawaj tokena dostępu do plików projektu ani do rozmowy.

## 4. Co potem?

Po udanym imporcie repozytorium będzie zawierać normalne pliki aplikacji. Dopiero wtedy konfigurujemy Cloudflare Pages, sekrety wdrożeniowe i później backend. Import sam w sobie nie publikuje aplikacji i nie uruchamia płatności.

Jeśli interfejs GitHuba na telefonie nie pokaże opcji **Upload files** albo **Create new file**, w Safari wybierz **aA → Poproś o witrynę komputerową** i powtórz krok.
