import type { Challenge, LibraryItem, ProductCard } from '../types';

/**
 * PRZYKŁADOWE DANE INTERFEJSU.
 * Nie są publicznym cennikiem ani opublikowaną ofertą. Przed startem sprzedaży
 * należy zastąpić je katalogiem pobieranym z API / bazy danych.
 */
export const sampleChallenges: Challenge[] = [
  {
    id: 'challenge-start',
    slug: 'dobry-start',
    title: 'Dobry start',
    summary: 'Uporządkuj podstawy i zacznij działać bez zgadywania, co zrobić dalej.',
    durationDays: 7,
    level: 'Początek',
    access: 'free',
    label: 'Przykład · bezpłatne',
    accent: 'lime',
    tasks: [
      'Określ jeden konkretny cel treningowy',
      'Zapisz punkt startowy i dostępny sprzęt',
      'Zaplanuj jeden realistyczny krok na dziś',
    ],
  },
  {
    id: 'challenge-regularity',
    slug: 'regularnosc',
    title: 'Rytm regularności',
    summary: 'Ćwicz konsekwencję i buduj nawyk, który pasuje do Twojego tygodnia.',
    durationDays: 14,
    level: 'Regularność',
    access: 'paid',
    label: 'Przykład · cena do ustawienia',
    accent: 'violet',
    tasks: [
      'Wybierz realne dni aktywności',
      'Zapisz wykonane zadanie',
      'Podsumuj tydzień i zaplanuj kolejny krok',
    ],
  },
  {
    id: 'challenge-progress',
    slug: 'kontrola-progresu',
    title: 'Kontrola progresu',
    summary: 'Naucz się obserwować regularność i postęp na podstawie własnych zapisów.',
    durationDays: 21,
    level: 'Progres',
    access: 'premium',
    label: 'Przykład · Premium',
    accent: 'orange',
    tasks: [
      'Wybierz wskaźnik, który będziesz zapisywać',
      'Porównaj dane z poprzednim tygodniem',
      'Podejmij jedną decyzję na podstawie zapisków',
    ],
  },
];

export const sampleLibrary: LibraryItem[] = [
  {
    id: 'book-start',
    title: 'Zacznij trenować',
    category: 'Materiał startowy',
    description: 'Praktyczne wprowadzenie do uporządkowanego treningu.',
    access: 'free',
    label: 'Bezpłatny materiał',
    accent: 'lime',
  },
  {
    id: 'book-home',
    title: 'System Formy · trening w domu',
    category: 'E-book',
    description: 'Miejsce na opis i plik produktu przeznaczony do sprzedaży.',
    access: 'paid',
    label: 'Cena do ustawienia',
    accent: 'violet',
  },
  {
    id: 'book-gym',
    title: 'System Formy · trening na siłowni',
    category: 'E-book',
    description: 'Miejsce na opis i plik produktu przeznaczony do sprzedaży.',
    access: 'paid',
    label: 'Cena do ustawienia',
    accent: 'orange',
  },
];

export const productCards: ProductCard[] = [
  {
    id: 'challenges',
    title: 'Wyzwania',
    eyebrow: 'DZIAŁAJ KROK PO KROKU',
    description: 'Krótkie, konkretne działania z możliwością zapisywania postępu.',
    access: 'paid',
    status: 'preview',
  },
  {
    id: 'ebooks',
    title: 'E-booki',
    eyebrow: 'WIEDZA POD RĘKĄ',
    description: 'Materiały edukacyjne dostępne po uzyskaniu odpowiednich uprawnień.',
    access: 'paid',
    status: 'preview',
  },
  {
    id: 'premium',
    title: 'System Formy Premium',
    eyebrow: 'WIĘCEJ MOŻLIWOŚCI',
    description: 'Dodatkowe funkcje i treści po skonfigurowaniu subskrypcji.',
    access: 'premium',
    status: 'coming-soon',
  },
  {
    id: 'individual',
    title: 'Plan indywidualny',
    eyebrow: 'DOPASOWANIE DO CIEBIE',
    description: 'Przyszła ścieżka zgłoszenia i przygotowania planu dla konkretnej osoby.',
    access: 'request',
    status: 'coming-soon',
  },
];
