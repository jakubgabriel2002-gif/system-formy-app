const baseUrl = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.trim().replace(/\/$/, '') ?? '';

export interface ApiChallenge {
  id: string;
  slug: string;
  title: string;
  summary: string;
  durationDays: number;
  difficulty: string | null;
  access: 'free' | 'paid' | 'premium' | 'request';
  priceAmountCents: number | null;
  currency: string;
}

export async function fetchPublishedChallenges(signal?: AbortSignal): Promise<ApiChallenge[] | null> {
  if (!baseUrl) return null;
  try {
    const response = await fetch(`${baseUrl}/api/challenges`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal,
    });
    if (!response.ok) return null;
    const payload: unknown = await response.json();
    if (!payload || typeof payload !== 'object' || !('data' in payload) || !Array.isArray(payload.data)) return null;
    return payload.data as ApiChallenge[];
  } catch {
    return null;
  }
}
