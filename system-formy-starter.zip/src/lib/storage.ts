const KEYS = {
  enrolled: 'sf-demo-enrolled-v1',
  completed: 'sf-demo-completed-v1',
  tasks: 'sf-demo-tasks-v1',
};

function readArray(key: string): string[] {
  try {
    const raw = window.localStorage.getItem(key);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) && parsed.every((item) => typeof item === 'string') ? parsed : [];
  } catch {
    return [];
  }
}

function writeArray(key: string, values: string[]): void {
  try {
    window.localStorage.setItem(key, JSON.stringify([...new Set(values)]));
  } catch {
    // Local persistence may be unavailable in private browsing; the UI still works for this session.
  }
}

export const demoStorage = {
  enrolled: () => readArray(KEYS.enrolled),
  completed: () => readArray(KEYS.completed),
  completedTasks: () => readArray(KEYS.tasks),
  enroll(id: string) {
    writeArray(KEYS.enrolled, [...readArray(KEYS.enrolled), id]);
  },
  completeChallenge(id: string) {
    writeArray(KEYS.completed, [...readArray(KEYS.completed), id]);
  },
  toggleTask(id: string) {
    const tasks = readArray(KEYS.tasks);
    writeArray(KEYS.tasks, tasks.includes(id) ? tasks.filter((task) => task !== id) : [...tasks, id]);
  },
  reset() {
    try {
      Object.values(KEYS).forEach((key) => window.localStorage.removeItem(key));
    } catch {
      // Ignore storage restrictions.
    }
  },
};
