export type ProductKind = 'challenge' | 'ebook' | 'premium' | 'individual-plan';
export type AccessLevel = 'free' | 'paid' | 'premium' | 'request';

export interface Challenge {
  id: string;
  slug: string;
  title: string;
  summary: string;
  durationDays: number;
  level: 'Początek' | 'Regularność' | 'Progres';
  access: AccessLevel;
  label: string;
  accent: 'lime' | 'violet' | 'orange';
  tasks: string[];
}

export interface LibraryItem {
  id: string;
  title: string;
  category: string;
  description: string;
  access: AccessLevel;
  label: string;
  accent: 'lime' | 'violet' | 'orange';
}

export interface ProductCard {
  id: string;
  title: string;
  eyebrow: string;
  description: string;
  access: AccessLevel;
  status: 'preview' | 'coming-soon' | 'available';
}
