import { useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Clock3,
  Crown,
  Dumbbell,
  Flame,
  Home,
  LockKeyhole,
  Menu,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  X,
  Zap,
} from 'lucide-react';
import { sampleChallenges, sampleLibrary } from './data/catalog';
import { demoStorage } from './lib/storage';
import type { Challenge, LibraryItem } from './types';

type Tab = 'overview' | 'challenges' | 'library' | 'premium' | 'profile';
type Notice = { title: string; body: string } | null;

const navItems: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: 'overview', label: 'Start', icon: Home },
  { id: 'challenges', label: 'Wyzwania', icon: Target },
  { id: 'library', label: 'Biblioteka', icon: BookOpen },
  { id: 'premium', label: 'Premium', icon: Crown },
];

function AccessPill({ access }: { access: string }) {
  const label = access === 'free' ? 'BEZPŁATNE' : access === 'premium' ? 'PREMIUM' : access === 'request' ? 'ZGŁOSZENIE' : 'PŁATNE';
  return <span className={`access-pill ${access}`}>{label}</span>;
}

function App() {
  const [tab, setTab] = useState<Tab>('overview');
  const [search, setSearch] = useState('');
  const [selectedChallenge, setSelectedChallenge] = useState<string | null>(null);
  const [notice, setNotice] = useState<Notice>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [, setRevision] = useState(0);
  const [filter, setFilter] = useState<'all' | 'free' | 'paid' | 'premium'>('all');
  const forceRefresh = () => setRevision((value) => value + 1);

  const enrolled = demoStorage.enrolled();
  const completed = demoStorage.completed();
  const completedTasks = demoStorage.completedTasks();
  const currentChallenge = selectedChallenge ? sampleChallenges.find((item) => item.id === selectedChallenge) : undefined;
  const activeChallenges = sampleChallenges.filter((item) => enrolled.includes(item.id) && !completed.includes(item.id));
  const filteredChallenges = useMemo(() => sampleChallenges.filter((item) => {
    const query = search.trim().toLocaleLowerCase('pl-PL');
    const matchesText = !query || `${item.title} ${item.summary} ${item.level}`.toLocaleLowerCase('pl-PL').includes(query);
    const matchesAccess = filter === 'all' || item.access === filter;
    return matchesText && matchesAccess;
  }), [search, filter]);
  const allTasks = activeChallenges.reduce((sum, challenge) => sum + challenge.tasks.length, 0);
  const doneTasks = activeChallenges.reduce((sum, challenge) => sum + challenge.tasks.filter((task, index) => completedTasks.includes(`${challenge.id}:${index}`)).length, 0);

  const openNotice = (title: string, body: string) => setNotice({ title, body });

  const enroll = (challenge: Challenge) => {
    if (challenge.access === 'paid' || challenge.access === 'premium') {
      openNotice('Płatności nie są jeszcze podłączone', 'To jest szkielet aplikacji. Katalog i interfejs są przygotowane, ale zakup, subskrypcja i weryfikacja dostępu wymagają jeszcze backendu oraz konfiguracji operatora płatności. Nie pobieramy żadnych opłat.');
      return;
    }
    if (!enrolled.includes(challenge.id)) demoStorage.enroll(challenge.id);
    setSelectedChallenge(challenge.id);
    setTab('challenges');
    forceRefresh();
  };

  const doTask = (challenge: Challenge, index: number) => {
    demoStorage.toggleTask(`${challenge.id}:${index}`);
    forceRefresh();
  };

  const finishChallenge = (challenge: Challenge) => {
    const missing = challenge.tasks.some((_, index) => !completedTasks.includes(`${challenge.id}:${index}`));
    if (missing) {
      openNotice('Jeszcze chwila', 'Odhacz wszystkie zadania wyzwania, aby oznaczyć je jako ukończone.');
      return;
    }
    demoStorage.completeChallenge(challenge.id);
    setSelectedChallenge(null);
    forceRefresh();
    openNotice('Dobra robota!', 'Wyzwanie oznaczono jako ukończone w tym demonstracyjnym widoku. Dane zapisują się wyłącznie w tej przeglądarce.');
  };

  const openLibraryItem = (item: LibraryItem) => {
    if (item.access !== 'free') {
      openNotice('Treść nie jest jeszcze podłączona', 'Karta produktu jest przykładowa. Przed sprzedażą trzeba dodać właściwy opis, cenę, plik w prywatnym magazynie i backend, który sprawdza uprawnienia użytkownika.');
      return;
    }
    openNotice('Materiał startowy', 'W tej wersji przygotowano miejsce na darmowy materiał. Plik PDF nie został dołączony publicznie do repozytorium. Po podłączeniu katalogu zostanie udostępniony bezpośrednio z aplikacji.');
  };

  const renderChallengeCard = (challenge: Challenge, index: number) => {
    const isActive = enrolled.includes(challenge.id) && !completed.includes(challenge.id);
    const isComplete = completed.includes(challenge.id);
    return (
      <article className={`challenge-card accent-${challenge.accent}`} key={challenge.id}>
        <div className="challenge-art">
          <div className="art-index">0{index + 1}</div>
          {challenge.accent === 'lime' ? <Dumbbell size={47} strokeWidth={1.2} /> : challenge.accent === 'violet' ? <Flame size={47} strokeWidth={1.2} /> : <Target size={47} strokeWidth={1.2} />}
          <span className="art-orbit orbit-one" />
          <span className="art-orbit orbit-two" />
          <span className="art-label">SYSTEM / {challenge.level.toUpperCase()}</span>
        </div>
        <div className="challenge-card-body">
          <div className="card-meta"><AccessPill access={challenge.access} /><span><Clock3 size={13} /> {challenge.durationDays} dni</span></div>
          <h3>{challenge.title}</h3>
          <p>{challenge.summary}</p>
          <div className="challenge-card-footer">
            <span className="demo-label">{challenge.label}</span>
            {isComplete ? <span className="done-label"><CheckCircle2 size={15} /> Ukończone</span> : isActive ? <button className="text-button" onClick={() => setSelectedChallenge(challenge.id)}>Kontynuuj <ArrowRight size={15} /></button> : <button className="text-button" onClick={() => enroll(challenge)}>Zobacz wyzwanie <ArrowRight size={15} /></button>}
          </div>
        </div>
      </article>
    );
  };

  const renderOverview = () => (
    <>
      <section className="welcome-row">
        <div>
          <p className="eyebrow"><span className="eyebrow-line" /> TWOJE MIEJSCE DO DZIAŁANIA</p>
          <h1>Mniej chaosu.<br /><span>Więcej konkretu.</span></h1>
          <p className="welcome-copy">Wyzwania, materiały i kontrola postępu. Wszystko po to, żebyś wiedział, jaki zrobić następny krok.</p>
          <div className="welcome-actions">
            <button className="button button-primary" onClick={() => setTab('challenges')}>Odkryj wyzwania <ArrowRight size={17} /></button>
            <button className="button button-quiet" onClick={() => setTab('library')}>Przejdź do biblioteki <ArrowUpRight size={16} /></button>
          </div>
        </div>
        <div className="hero-visual" aria-label="Grafika typograficzna System Formy">
          <div className="hero-visual-top"><span>SF / 001</span><span>PROCESS OVER NOISE</span></div>
          <div className="hero-ring"><div className="hero-ring-inner"><span>TWÓJ</span><strong>RUCH.</strong><i /></div></div>
          <div className="hero-visual-bottom"><span>01 — USTAL KIERUNEK</span><ArrowDownRight size={17} /></div>
          <div className="hero-side-mark">SYSTEM<br />FORMY</div>
        </div>
      </section>

      <div className="demo-banner"><span className="demo-dot" /><div><strong>Wersja demonstracyjna</strong><span>Postęp zapisuje się na tym urządzeniu. Konto, płatności i prywatne treści nie są jeszcze podłączone.</span></div><button aria-label="Więcej o wersji demonstracyjnej" onClick={() => openNotice('Co działa w tej wersji?', 'Możesz przechodzić między sekcjami, filtrować wyzwania, rozpocząć przykładowe bezpłatne wyzwanie i zapisywać odhaczane zadania w lokalnej przeglądarce. Nie ma jeszcze prawdziwych kont, synchronizacji, zamówień, płatności ani zabezpieczonych plików.')}><CircleHelp size={18} /></button></div>

      <section className="section-block stats-section">
        <div className="section-heading"><div><p className="eyebrow">TWÓJ PROCES</p><h2>Małe kroki. <span>Jasny kierunek.</span></h2></div><span className="section-note">DANE Z TEGO URZĄDZENIA</span></div>
        <div className="stats-grid">
          <div className="stat-card"><div className="stat-icon lime-icon"><Target size={18} /></div><div className="stat-number">{activeChallenges.length.toString().padStart(2, '0')}</div><div className="stat-label">Aktywne wyzwania</div><div className="stat-foot">W trakcie realizacji</div></div>
          <div className="stat-card"><div className="stat-icon violet-icon"><CheckCircle2 size={18} /></div><div className="stat-number">{doneTasks.toString().padStart(2, '0')}<span>/{allTasks.toString().padStart(2, '0')}</span></div><div className="stat-label">Zrobione zadania</div><div className="stat-foot">Tylko aktywne wyzwania</div></div>
          <div className="stat-card"><div className="stat-icon orange-icon"><Flame size={18} /></div><div className="stat-number">{completed.length.toString().padStart(2, '0')}</div><div className="stat-label">Ukończone wyzwania</div><div className="stat-foot">Twój zapisany wynik</div></div>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading"><div><p className="eyebrow">ZACZNIJ OD JEDNEGO KROKU</p><h2>Wyzwania <span>na teraz.</span></h2></div><button className="text-button section-link" onClick={() => setTab('challenges')}>Zobacz wszystkie <ArrowRight size={16} /></button></div>
        <div className="challenge-grid">{sampleChallenges.slice(0, 2).map(renderChallengeCard)}</div>
      </section>

      <section className="premium-strip">
        <div className="premium-strip-icon"><Crown size={25} /></div>
        <div className="premium-strip-copy"><p className="eyebrow">DLA TYCH, KTÓRZY CHCĄ WIĘCEJ</p><h2>System Formy <span>Premium</span></h2><p>Dodatkowe treści i możliwości w jednej subskrypcji — szczegóły pojawią się po uruchomieniu oferty.</p></div>
        <button className="button button-outline" onClick={() => setTab('premium')}>Poznaj Premium <ArrowRight size={16} /></button>
        <div className="premium-ornament">SF<span>+</span></div>
      </section>
    </>
  );

  const renderChallenges = () => (
    <section className="page-section">
      {currentChallenge ? (
        <div className="challenge-detail">
          <button className="back-link" onClick={() => setSelectedChallenge(null)}><ArrowLeft size={16} /> Wróć do wyzwań</button>
          <div className={`detail-banner accent-${currentChallenge.accent}`}>
            <div className="detail-banner-copy"><p className="eyebrow">WYZWANIE / {currentChallenge.level.toUpperCase()}</p><h1>{currentChallenge.title}<span>.</span></h1><p>{currentChallenge.summary}</p><div className="detail-tags"><span><Clock3 size={14} /> {currentChallenge.durationDays} dni</span><AccessPill access={currentChallenge.access} /></div></div>
            <div className="detail-banner-icon"><Dumbbell size={68} strokeWidth={1} /></div>
          </div>
          <div className="section-heading detail-heading"><div><p className="eyebrow">LISTA DZIAŁAŃ</p><h2>Zrób kolejny <span>krok.</span></h2></div><span className="section-note">{currentChallenge.tasks.filter((_, index) => completedTasks.includes(`${currentChallenge.id}:${index}`)).length} / {currentChallenge.tasks.length} ZADAŃ</span></div>
          <div className="task-list">{currentChallenge.tasks.map((task, index) => {
            const key = `${currentChallenge.id}:${index}`;
            const done = completedTasks.includes(key);
            return <button className={`task-row ${done ? 'is-done' : ''}`} key={key} onClick={() => doTask(currentChallenge, index)}><span className="task-check">{done && <Check size={15} />}</span><span className="task-index">0{index + 1}</span><span className="task-title">{task}</span><span className="task-toggle">{done ? 'WYKONANO' : 'OZNACZ'}</span></button>;
          })}</div>
          <button className="button button-primary finish-button" onClick={() => finishChallenge(currentChallenge)}>Zakończ wyzwanie <CheckCircle2 size={17} /></button>
        </div>
      ) : (
        <>
          <div className="page-title-row"><div><p className="eyebrow"><span className="eyebrow-line" /> WYBIERZ SWÓJ NASTĘPNY KROK</p><h1>Wyzwania<span>.</span></h1><p className="page-intro">Konkretne zadania pomagają uporządkować działanie. Wybierz wyzwanie i przejdź je we własnym tempie.</p></div><div className="title-count"><strong>0{sampleChallenges.length}</strong><span>PRZYKŁADY</span></div></div>
          <div className="filter-row"><label className="search-field"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Szukaj wyzwania..." aria-label="Szukaj wyzwania" />{search && <button onClick={() => setSearch('')} aria-label="Wyczyść wyszukiwanie"><X size={15} /></button>}</label><div className="filter-pills">{(['all', 'free', 'paid', 'premium'] as const).map((item) => <button className={filter === item ? 'filter-pill active' : 'filter-pill'} key={item} onClick={() => setFilter(item)}>{item === 'all' ? 'Wszystkie' : item === 'free' ? 'Bezpłatne' : item === 'paid' ? 'Płatne' : 'Premium'}</button>)}</div></div>
          <div className="challenge-grid challenge-grid-large">{filteredChallenges.length ? filteredChallenges.map(renderChallengeCard) : <div className="empty-state"><Search size={25} /><strong>Nie znaleźliśmy takiego wyzwania.</strong><span>Zmień hasło lub filtr i spróbuj ponownie.</span><button className="text-button" onClick={() => { setSearch(''); setFilter('all'); }}>Wyczyść filtry <ArrowRight size={15} /></button></div>}</div>
        </>
      )}
    </section>
  );

  const renderLibrary = () => (
    <section className="page-section">
      <div className="page-title-row"><div><p className="eyebrow"><span className="eyebrow-line" /> MATERIAŁY W JEDNYM MIEJSCU</p><h1>Biblioteka<span>.</span></h1><p className="page-intro">Wracaj do wiedzy, kiedy jej potrzebujesz. Płatne pliki będą udostępniane po zweryfikowaniu uprawnień.</p></div><div className="title-count"><BookOpen size={26} /><span>MATERIAŁY</span></div></div>
      <div className="library-callout"><ShieldCheck size={21} /><div><strong>Pliki klientów muszą być prywatne</strong><span>W tym starterze nie ma plików płatnych ani publicznych linków do chronionych materiałów.</span></div></div>
      <div className="library-grid">{sampleLibrary.map((item) => <article className={`library-card accent-${item.accent}`} key={item.id}><div className="library-art"><div className="library-art-grid" /><BookOpen size={34} strokeWidth={1.2} /><span className="library-art-caption">SYSTEM<br />FORMY</span></div><div className="library-content"><span className="library-category">{item.category}</span><h3>{item.title}</h3><p>{item.description}</p><div className="library-card-footer"><span className="demo-label">{item.label}</span>{item.access === 'free' ? <button className="text-button" onClick={() => openLibraryItem(item)}>Otwórz <ArrowRight size={15} /></button> : <button className="text-button" onClick={() => openLibraryItem(item)}><LockKeyhole size={14} /> Szczegóły</button>}</div></div></article>)}</div>
    </section>
  );

  const renderPremium = () => (
    <section className="page-section premium-page">
      <div className="premium-cover"><div className="premium-cover-top"><span>SF / PREMIUM</span><span>MEMBERS AREA</span></div><div className="premium-cover-main"><div className="premium-symbol"><Crown size={48} strokeWidth={1.1} /></div><p className="eyebrow">SYSTEM FORMY / MEMBERSHIP</p><h1>Twój proces.<br /><span>Więcej możliwości.</span></h1><p>Premium jest zaplanowany jako subskrypcja, ale nie został jeszcze uruchomiony. Cena, zakres i płatności muszą zostać zatwierdzone przed startem.</p><button className="button button-primary" onClick={() => openNotice('Premium nie jest jeszcze aktywne', 'Ta karta przedstawia kierunek interfejsu, a nie działającą ofertę. Przed uruchomieniem trzeba zatwierdzić dokładny zakres Premium, cenę, odnowienia, rezygnację, regulamin i obsługę płatności.')} >Sprawdź status Premium <ArrowRight size={17} /></button></div><div className="premium-cover-footer"><span>NO GUESSWORK.</span><span>ONE STEP AT A TIME.</span></div></div>
      <div className="premium-benefits"><p className="eyebrow">ZAŁOŻENIA PRODUKTU</p><h2>Co planujemy <span>uwzględnić?</span></h2><div className="benefit-row"><span><Sparkles size={18} /></span><div><strong>Dodatkowe wyzwania i treści</strong><p>Zakres do ustalenia — bez obiecywania funkcji, które nie zostały wdrożone.</p></div><span className="planned">PLANOWANE</span></div><div className="benefit-row"><span><Zap size={18} /></span><div><strong>Jedno miejsce na postęp</strong><p>Docelowo synchronizowany zapis po uruchomieniu kont i backendu.</p></div><span className="planned">PLANOWANE</span></div><div className="benefit-row"><span><ShieldCheck size={18} /></span><div><strong>Osobno zakupione produkty pozostają dostępne</strong><p>Reguła dostępu do wdrożenia w backendzie, niezależnie od statusu subskrypcji.</p></div><span className="planned">WYMAGA IMPLEMENTACJI</span></div></div>
    </section>
  );

  const renderProfile = () => (
    <section className="page-section profile-page"><div className="page-title-row"><div><p className="eyebrow"><span className="eyebrow-line" /> TWOJE USTAWIENIA</p><h1>Profil<span>.</span></h1><p className="page-intro">Na razie korzystasz z trybu demonstracyjnego, bez konta i synchronizacji między urządzeniami.</p></div></div><div className="profile-card"><div className="profile-avatar">SF</div><div className="profile-info"><span className="access-pill free">TRYB DEMO</span><h2>Użytkownik testowy</h2><p>Brak konta · lokalne zapisy w tej przeglądarce</p></div><button className="button button-outline" onClick={() => openNotice('Logowanie nie jest podłączone', 'Rejestracja, logowanie, resetowanie hasła oraz zapis danych na serwerze to kolejny etap prac. Nie wpisuj tu żadnych haseł — nie ma działającego formularza logowania.')}><LockKeyhole size={16} /> Konto docelowe</button></div><div className="settings-card"><div><strong>Wyczyść dane demonstracyjne</strong><p>Usunie lokalne zapisy rozpoczętych i ukończonych wyzwań z tego urządzenia.</p></div><button className="button button-danger-quiet" onClick={() => openNotice('Wyczyścić lokalne zapisy?', 'Potwierdź usunięcie w tym oknie, aby usunąć wyłącznie demonstracyjne postępy zapisane w tej przeglądarce.')}><X size={15} /> Wyczyść</button></div></section>
  );

  const pageTitle = navItems.find((item) => item.id === tab)?.label ?? 'Profil';

  return (
    <div className="app-frame">
      <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
        <button className="brand-lockup" onClick={() => { setTab('overview'); setMenuOpen(false); }} aria-label="System Formy — strona główna"><span className="brand-mark">SF<span>.</span></span><span className="brand-wordmark">SYSTEM<br />FORMY</span></button>
        <div className="sidebar-label">PRZESTRZEŃ</div>
        <nav className="side-nav" aria-label="Nawigacja główna">{navItems.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${tab === id ? 'active' : ''}`} onClick={() => { setTab(id); setSelectedChallenge(null); setMenuOpen(false); }}><Icon size={18} strokeWidth={1.8} /><span>{label}</span>{id === 'premium' && <span className="nav-plus">+</span>}{tab === id && <span className="nav-active-line" />}</button>)}</nav>
        <div className="sidebar-bottom"><div className="sidebar-note"><div className="sidebar-note-icon"><Dumbbell size={18} /></div><p>LICZY SIĘ PROCES.<br /><strong>NIE PRZYPADEK.</strong></p><span>SF / 001</span></div><button className={`nav-item profile-nav ${tab === 'profile' ? 'active' : ''}`} onClick={() => { setTab('profile'); setMenuOpen(false); }}><span className="profile-mini">SF</span><span>Profil i ustawienia</span><ChevronDown size={15} /></button><div className="sidebar-version">SYSTEM FORMY <span>·</span> STARTER 0.1</div></div>
      </aside>

      {menuOpen && <button className="mobile-scrim" aria-label="Zamknij menu" onClick={() => setMenuOpen(false)} />}
      <main className="main-area">
        <header className="topbar"><div className="topbar-left"><button className="mobile-menu-button" onClick={() => setMenuOpen((value) => !value)} aria-label="Otwórz menu"><Menu size={21} /></button><span className="topbar-section">TWOJA PRZESTRZEŃ</span><span className="topbar-divider">/</span><span className="topbar-current">{pageTitle}</span></div><div className="topbar-right"><span className="status-tag"><span /> DEMO</span><button className="topbar-avatar" onClick={() => setTab('profile')} aria-label="Otwórz profil">SF</button></div></header>
        <div className="content-wrap">
          {tab === 'overview' && renderOverview()}
          {tab === 'challenges' && renderChallenges()}
          {tab === 'library' && renderLibrary()}
          {tab === 'premium' && renderPremium()}
          {tab === 'profile' && renderProfile()}
          <footer className="app-footer"><span>© {new Date().getFullYear()} SYSTEM FORMY</span><span>PORZĄDEK W TRENINGU. JASNY NASTĘPNY KROK.</span><button onClick={() => openNotice('Informacja o wersji', 'To projekt startowy. Przed udostępnieniem publicznym trzeba dodać politykę prywatności, regulamin, informacje o sprzedawcy oraz rzeczywistą obsługę zgód i danych.')}><CircleHelp size={14} /> Informacje</button></footer>
        </div>
        <nav className="mobile-bottom-nav" aria-label="Nawigacja mobilna">{navItems.map(({ id, label, icon: Icon }) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => { setTab(id); setSelectedChallenge(null); }}><Icon size={20} /><span>{label}</span></button>)}</nav>
      </main>

      {notice && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setNotice(null); }}><section className="notice-modal" role="dialog" aria-modal="true" aria-labelledby="notice-title"><button className="modal-close" onClick={() => setNotice(null)} aria-label="Zamknij okno"><X size={19} /></button><div className="modal-symbol"><CircleHelp size={23} /></div><p className="eyebrow">SYSTEM FORMY / INFORMACJA</p><h2 id="notice-title">{notice.title}</h2><p className="modal-body">{notice.body}</p>{notice.title === 'Wyczyścić lokalne zapisy?' ? <div className="modal-actions"><button className="button button-outline" onClick={() => setNotice(null)}>Anuluj</button><button className="button button-danger" onClick={() => { demoStorage.reset(); setSelectedChallenge(null); forceRefresh(); setNotice({ title: 'Dane wyczyszczone', body: 'Lokalne dane demonstracyjne zostały usunięte.' }); }}>Potwierdź usunięcie</button></div> : <button className="button button-primary modal-okay" onClick={() => setNotice(null)}>Rozumiem <ArrowRight size={16} /></button>}</section></div>}
    </div>
  );
}

export default App;
